from flask_wtf import FlaskForm
from wtforms import StringField, PasswordField, validators, SubmitField
from wtforms.validators import EqualTo, Length, Email,DataRequired, ValidationError
from market1.models import User

class RegisterForm(FlaskForm):
    def validate_username(self, user_to_check):
        user = User.query.filter_by(username = user_to_check.data).first()
        if user:
            raise ValidationError("Username already exits! Try different user name")

    def validate_email_address(self, email_to_check):
        email = User.query.filter_by(email_address = email_to_check.data).first()
        if email:
            raise ValidationError("Email already exits! Try different email")


    username = StringField(label='username:', validators=[Length(min=2, max=20), DataRequired()])
    email_address = StringField(label='email:', validators=[Email(), DataRequired()])
    password1 = PasswordField(label='password:', validators=[Length(min=6), DataRequired()])
    password2 = PasswordField(label='confirm password:', validators=[EqualTo('password1'), DataRequired()])
    submit = SubmitField(label='Create account')

class LoginForm(FlaskForm):
    username = StringField(label='username:', validators=[DataRequired()])
    password = PasswordField(label='password:', validators=[DataRequired()])
    submit = SubmitField(label='Sign In')

class PurchaseItem(FlaskForm):
    submit= SubmitField(label='Purchase')

class SellItem(FlaskForm):
    submit= SubmitField(label='Sell Item')


